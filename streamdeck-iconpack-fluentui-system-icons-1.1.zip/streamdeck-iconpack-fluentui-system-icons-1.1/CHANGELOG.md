# Changelog

## v1.0 (2021-10-04)

- Initial release
